<?php echo value($html); ?>

<?php /**PATH C:\laragon\www\SIPenjualan\vendor\filament\support\resources\views/anonymous-partial.blade.php ENDPATH**/ ?>